#!/bin/bash
ln -s /opt/openrbc/src/openrbc /usr/local/bin/openrbc
